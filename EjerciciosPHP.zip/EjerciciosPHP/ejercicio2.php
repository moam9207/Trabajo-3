<html lang="es">
<head>
  <title>Ejercicio 2</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8"/>
 </head>
  <body>
  <div class="enpi">
    <h1>PROGRAMACION DE APLICACIONES WEB</h1>
	<h4>Mostrar en pantalla una tabla de 10 por 10 con los numeros del 1 al 100</h4>
	</div>
<?php
  echo "<table border=1>";
  $n=1;
  for ($n1=1; $n1<=10; $n1++)
  {
	echo "<tr>";
    for ($n2=1; $n2<=10; $n2++)
	{
		echo "<td>", $n, "</td>";
        $n=$n+1;
	}
	echo "</tr>";
  }
  echo "</table>";
   ?>
   <div class="enpi">
   <p>Nombre del alumno: Mario Luis Morales Albores</p>
   <a href="index.php">Regresar a menu</a>
   </div>
   </body>
   </html>