<html lang="es">
<head>
  <title>Ejercicio 5</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8"/>
 </head>
  <body>
  <div class="enpi"> 
    <h1>PROGRAMACION DE APLICACIONES WEB</h1>
	<h4>Mostrar en pantalla cual es el mayor de tres numeros</h4>
</div> 
	<?php
$n1=10;
$n2=9;
$n3=7;
if (($n1 > $n2) && ($n1 > $n3)) {
   echo "El primer número (".$n1.") es el mayor";
}
 elseif (($n2 > $n1) && ($n2 > $n3)) {
echo "El segundo número (".$n2.") es el mayor";
}
 elseif (($n3 > $n1) && ($n3 > $n2)) {
 echo "El tercer número (".$n3.") es el mayor";
}
elseif (($n1 == $n2 ) && ($n2==$n3)) {
 echo "Todos son iguales";
}
echo "<br />";

if (($n1 < $n2) && ($n1 < $n3)) {
    echo "El primer número (".$n1.") es el menor";
} elseif (($n2 < $n1) && ($n2 < $n1)) {
echo "El segundo número (".$n2.") es el menor";
} elseif (($n3 < $n1) && ($n3 < $n2)) {
 echo "El tercer número (".$n3.") es el menor";
}


?>
<div class="enpi">   
  <p>Nombre del alumno: Mario Luis Morales Albores</p>
   <a href="index.php">Regresar a menu</a>
   </div> 
   </body>
   </html>
