<html lang="es">
<head>
  <title>Ejercicios en PHP</title>
  <link rel="stylesheet" type="text/css"href="css/style.css"/>
  <meta charset="utf-8"/>
 </head>
  <body>
  <div class="enpi"> 
    <center><h1>EJERCICIOS PHP</h1></center>
	 <center><h1>VARIABLES</h1></center>
	 </div>
	 <center><ul>
	  <li><a href="ejercicio1.php">Ejercicio 1 </a></li>
	  <li><a href="ejercicio2.php">Ejercicio 2 </a></li>
	  <li><a href="ejercicio3.php">Ejercicio 3 </a></li>
	  <li><a href="ejercicio4.php">Ejercicio 4 </a></li>
	  <li><a href="ejercicio5.php">Ejercicio 5 </a></li>
     </ul>  </center>
	  <div class="enpi">
	  <p>UNIVERSIDAD AUTONOMA DE CHIAPAS</p>
	  <img src="img/unach.png" width="150px" height="150px" />
	  <h4>Derechos Reservados A: Mario Luis Morales Albores</h4>
	  <h4>UNACH LSC 5B</h4>
	  	  	  
	  </div>
   </body>
   </html>   