<html lang="es">
<head>
  <title>Ejercicio 4</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8"/>
 </head>
  <body>
<div class="enpi">  
  <h1>PROGRAMACION DE APLICACIONES WEB</h1>
	<h4>Mostrar en pantalla cual es el mayor de dos numeros</h4>
</div>
	<?php
$n1=550;
$n2=5400;
   
if ($n1>$n2){
	echo "<td>";
echo "El primer número (".$n1.") es mayor que el segundo (".$n2.")";
echo "</td>";
}
elseif ($n1==$n2){
echo "El primer número (".$n1.") es igual al segundo (".$n2.")";
}
else{
echo "El primer número (".$n1.") es menor que el segundo (".$n2.")";
}

?>
<div class="enpi">
   <p>Nombre del alumno: Mario Luis Morales Albores</p>
   <a href="index.php">Regresar a menu</a>
   
   </div>
   </body>
   </html>
