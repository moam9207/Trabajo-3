<html lang="es">
<head>
  <title>Ejercicio 1</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta charset="utf-8"/>
 </head>
  <body>
  <div class="enpi">
    <h1>PROGRAMACION DE APLICACIONES WEB</h1>
	<h4>Hacer un programa que sume,reste,multiplique y divida dos variables</h4>
  </div>
	<?php
   $numero1=10;
   $numero2=12;
   echo "<table border=1 >";
   echo "<tr>";
   echo "<td>";
   echo "La Suma:<Br/>";
   $suma=$numero1+$numero2;
   echo "$numero1+$numero2"."<br>";
   echo "Suma = ".$suma."<br>";
   echo "</td>";
   echo "<td>";
   echo "La resta:<Br/>";
   $resta=$numero1-$numero2;
   echo "$numero1-$numero2"."<br>";
   echo "Resta = ".$resta."<br>";
   echo "</td>";
   echo "<td>";
   echo "La Multiplicacion:<Br/>";
   $multip=$numero1*$numero2;
   echo "$numero1*$numero2"."<br>";
   echo "Multiplicacion = ".$multip."<br>";
   echo "</td>";
   echo "<td>";
   echo "La division:<Br/>";
   $divicion=$numero1/$numero2;
   echo "$numero1/$numero2"."<br>";
   echo "division = ".$divicion."<br>";
   echo "<td>";
   echo "</tr>";
   echo "</table>";
   ?>
   <div class="enpi">
   <p>Nombre del alumno: Mario Luis Morales Albores</p>
   <a href="index.php">Regresar a menu</a>
   </div>
   </body>
   </html>